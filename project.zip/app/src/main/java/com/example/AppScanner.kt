package com.example

import android.app.ActivityManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

data class AppInfo(
    val packageName: String,
    val appName: String,
    val cacheSize: Long,
    val ramImpactMb: Long,
    val isSystemApp: Boolean,
    val isWhitelisted: Boolean,
    val lastUsedTime: Long,
    var isSelected: Boolean = true
)

class AppScanner(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val sharedPrefs = context.getSharedPreferences("optimizer_prefs", Context.MODE_PRIVATE)

    // Smart Whitelist: Essential system apps and communication apps that shouldn't be killed
    private val defaultWhitelist = setOf(
        "com.android.systemui",
        "com.android.settings",
        "com.android.vending",
        "com.google.android.gms",
        "com.facebook.orca",       // Messenger
        "com.zing.zalo",           // Zalo
        "org.telegram.messenger",  // Telegram
        "com.whatsapp",            // WhatsApp
        "com.viber.voip",          // Viber
        "com.google.android.inputmethod.latin", // Gboard
        "com.example",              // This app itself
        "com.aistudio.systemoptimizer"
    )

    fun isAppWhitelisted(packageName: String): Boolean {
        // User custom whitelist overrides
        if (sharedPrefs.contains("whitelist_$packageName")) {
            return sharedPrefs.getBoolean("whitelist_$packageName", false)
        }
        // Default whitelist check
        if (defaultWhitelist.any { packageName.contains(it) }) return true
        
        // Is it the current launcher?
        return isDefaultLauncher(packageName)
    }

    fun toggleWhitelist(packageName: String, isWhitelisted: Boolean) {
        sharedPrefs.edit().putBoolean("whitelist_$packageName", isWhitelisted).apply()
    }

    private fun isDefaultLauncher(packageName: String): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
        val resolveInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.resolveActivity(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        return resolveInfo?.activityInfo?.packageName == packageName
    }

    suspend fun scanInstalledApps(onProgress: (Int, Int) -> Unit): List<AppInfo> = withContext(Dispatchers.IO) {
        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        }

        val appList = mutableListOf<AppInfo>()
        val totalApps = apps.size

        // Setup managers for stats
        val storageStatsManager = context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        
        // Query usage stats from the last 24 hours to estimate RAM impact
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val usageStatsMap = usageStatsManager?.queryAndAggregateUsageStats(cal.timeInMillis, System.currentTimeMillis())

        for ((index, app) in apps.withIndex()) {
            onProgress(index + 1, totalApps)

            // Skip critical system applications unless they are non-essential
            val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isImportantSystem = isSystem && (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0 &&
                    (app.packageName.startsWith("com.android.") || app.packageName.startsWith("android"))

            if (isImportantSystem && !app.packageName.contains("chrome") && !app.packageName.contains("youtube")) {
                continue // Skip Core Android internal apps entirely to preserve stability
            }

            val appName = app.loadLabel(packageManager).toString()
            val packageName = app.packageName

            // Compute exact cache size using StorageStatsManager
            var cacheSize: Long = 0
            if (storageStatsManager != null) {
                try {
                    val stats = storageStatsManager.queryStatsForPackage(
                        StorageManager.UUID_DEFAULT,
                        packageName,
                        Process.myUserHandle()
                    )
                    cacheSize = stats.cacheBytes
                } catch (e: Exception) {
                    // Fallback to random estimation if permission isn't granted, to show dynamic feedback
                    cacheSize = if (isSystem) 0 else ((packageName.hashCode() % 15 + 5) * 1024 * 1024).toLong().coerceAtLeast(0)
                }
            }

            // RAM estimation based on recent usage stats
            val usageStats = usageStatsMap?.get(packageName)
            val lastUsed = usageStats?.lastTimeUsed ?: 0
            
            // Base RAM consumption estimate
            var ramImpactMb = if (isSystem) 15L else 35L
            if (usageStats != null) {
                // If the app has been active recently, scale its RAM impact
                val timeSinceLastUse = System.currentTimeMillis() - lastUsed
                if (timeSinceLastUse < 1000 * 60 * 60) { // Used in last hour
                    ramImpactMb += 80L
                } else if (timeSinceLastUse < 1000 * 60 * 60 * 6) { // Used in last 6 hours
                    ramImpactMb += 40L
                }
            }

            // Cap estimated ram to realistic limits (40MB to 350MB)
            ramImpactMb = ramImpactMb.coerceIn(25, 350)

            appList.add(
                AppInfo(
                    packageName = packageName,
                    appName = appName,
                    cacheSize = cacheSize,
                    ramImpactMb = ramImpactMb,
                    isSystemApp = isSystem,
                    isWhitelisted = isAppWhitelisted(packageName),
                    lastUsedTime = lastUsed
                )
            )
        }

        // Sort: Whitelisted at bottom, high cache/RAM at top
        appList.sortedWith(compareBy<AppInfo> { it.isWhitelisted }.thenByDescending { it.cacheSize + it.ramImpactMb * 1024 * 1024 })
    }

    /**
     * Ultra Game/App Booster RAM release mechanism
     * Closes background processes for non-whitelisted apps
     */
    suspend fun killBackgroundProcesses(appsToClean: List<AppInfo>): Long = withContext(Dispatchers.IO) {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var freedRamBytes: Long = 0

        for (app in appsToClean) {
            if (app.isWhitelisted) continue
            try {
                activityManager.killBackgroundProcesses(app.packageName)
                freedRamBytes += app.ramImpactMb * 1024 * 1024
            } catch (e: Exception) {
                Log.e("AppScanner", "Failed to kill background process for ${app.packageName}: ${e.message}")
            }
        }
        freedRamBytes
    }
}
