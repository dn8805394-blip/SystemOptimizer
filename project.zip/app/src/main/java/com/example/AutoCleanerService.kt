package com.example

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow

class AutoCleanerService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning.value = true
        Log.d(TAG, "AutoCleanerService Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!isSweepingActive.value) return

        val rootNode = rootInActiveWindow ?: return
        val packageName = event.packageName?.toString() ?: ""

        // Only automate within system settings or package installer/settings pages
        if (packageName.contains("settings") || packageName.contains("packageinstaller")) {
            processNode(rootNode)
        }
        rootNode.recycle()
    }

    private fun processNode(node: AccessibilityNodeInfo) {
        val nodeText = node.text?.toString()?.lowercase() ?: ""
        val contentDesc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        // 1. If we are in "Clear Cache" mode:
        if (currentAction.value == ActionType.CLEAR_CACHE) {
            // Check if we need to click "Storage" first to enter the Storage sub-page
            if (isStorageKeyword(nodeText) || isStorageKeyword(contentDesc)) {
                if (node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Clicked Storage sub-menu: $nodeText")
                    return
                } else {
                    node.parent?.let { parent ->
                        if (parent.isClickable) {
                            parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            Log.d(TAG, "Clicked parent Storage sub-menu")
                            return
                        }
                    }
                }
            }

            // Click "Clear Cache" button
            if (isClearCacheKeyword(nodeText) || isClearCacheKeyword(contentDesc) || viewId.contains("clear_cache")) {
                if (node.isEnabled && node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Clicked Clear Cache button")
                    // Notify system cache is cleared for this app
                    actionCompleted()
                    return
                }
            }
        }

        // 2. If we are in "Force Stop" mode:
        if (currentAction.value == ActionType.FORCE_STOP) {
            // Click "Force Stop" button
            if (isForceStopKeyword(nodeText) || isForceStopKeyword(contentDesc) || viewId.contains("force_stop") || viewId.contains("stop_button")) {
                if (node.isEnabled) {
                    if (node.isClickable) {
                        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        Log.d(TAG, "Clicked Force Stop button")
                        return
                    } else {
                        node.parent?.let { parent ->
                            if (parent.isClickable) {
                                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                                Log.d(TAG, "Clicked parent Force Stop button")
                                return
                            }
                        }
                    }
                } else {
                    // Button is already disabled, meaning the app is already stopped!
                    Log.d(TAG, "Force Stop button is already disabled (stopped)")
                    actionCompleted()
                    return
                }
            }

            // Also check for Dialog confirmation button (e.g. OK / Yes / Force stop)
            if (isConfirmKeyword(nodeText) || isConfirmKeyword(contentDesc) || viewId.contains("button1") || viewId.contains("ok_button")) {
                if (node.isEnabled && node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Clicked Confirm OK button in Dialog")
                    actionCompleted()
                    return
                }
            }
        }

        // Recursively traverse child nodes
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                processNode(child)
                child.recycle()
            }
        }
    }

    private fun isStorageKeyword(text: String): Boolean {
        return text.contains("storage") || 
               text.contains("dung lượng") || 
               text.contains("lưu trữ") || 
               text.contains("bộ nhớ") || 
               text.contains("bộ nhớ lưu trữ")
    }

    private fun isClearCacheKeyword(text: String): Boolean {
        return text.contains("clear cache") || 
               text.contains("xóa bộ nhớ đệm") || 
               text.contains("xóa cache") || 
               text.contains("xóa dữ liệu đệm")
    }

    private fun isForceStopKeyword(text: String): Boolean {
        val t = text.trim()
        return t.contains("force stop") || 
               t.contains("buộc dừng") || 
               t.contains("tắt cưỡng bức") || 
               t.contains("ngưng hoạt động") ||
               t.contains("dừng ứng dụng")
    }

    private fun isConfirmKeyword(text: String): Boolean {
        val t = text.trim()
        return t == "ok" || 
               t == "yes" || 
               t == "đồng ý" || 
               t == "xác nhận" || 
               t == "buộc dừng" || 
               t == "force stop"
    }

    private fun actionCompleted() {
        Log.d(TAG, "Action completed successfully")
        lastCompletedPackage.value = currentSweepingPackage.value
    }

    override fun onInterrupt() {
        isServiceRunning.value = false
        Log.d(TAG, "AutoCleanerService Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning.value = false
        Log.d(TAG, "AutoCleanerService Destroyed")
    }

    enum class ActionType {
        NONE, CLEAR_CACHE, FORCE_STOP
    }

    companion object {
        private const val TAG = "AutoCleanerService"

        // Reactive states accessible from ViewModel/MainActivity
        val isServiceRunning = MutableStateFlow(false)
        val isSweepingActive = MutableStateFlow(false)
        val currentSweepingPackage = MutableStateFlow<String?>(null)
        val currentAction = MutableStateFlow(ActionType.NONE)
        
        // Tells the cleaner loop that the action has been executed
        val lastCompletedPackage = MutableStateFlow<String?>(null)
    }
}
