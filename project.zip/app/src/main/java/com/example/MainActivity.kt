package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModelProvider
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.absoluteValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) { // Force Dark Mode to save power and GPU cycles
                val context = LocalContext.current
                val factory = ViewModelFactory(context.applicationContext)
                val viewModel: OptimizerViewModel = viewModel(factory = factory)
                
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OptimizerAppScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Check permissions whenever app gets focus back from Settings
        val factory = ViewModelFactory(applicationContext)
        val viewModel = ViewModelProvider(this, factory)[OptimizerViewModel::class.java]
        viewModel.checkPermissions()
        viewModel.updateRamStats()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptimizerAppScreen(viewModel: OptimizerViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val ramPercent by viewModel.ramUsagePercent.collectAsStateWithLifecycle()
    val ramText by viewModel.ramAvailableText.collectAsStateWithLifecycle()
    val isAccessibilityEnabled by viewModel.isAccessibilityEnabled.collectAsStateWithLifecycle()
    val isUsageStatsEnabled by viewModel.isUsageStatsEnabled.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.OfflineBolt,
                            contentDescription = null,
                            tint = Color(0xFFFFB74D),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SYSTEM OPTIMIZER",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Permission Warnings at the top
            PermissionBanner(
                isAccessibilityEnabled = isAccessibilityEnabled,
                isUsageStatsEnabled = isUsageStatsEnabled,
                onRequestAccessibility = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        Toast.makeText(context, "Hãy bật 'Trợ lý Tối ưu hóa Hệ thống'", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Không thể mở Cài đặt Trợ năng", Toast.LENGTH_SHORT).show()
                    }
                },
                onRequestUsageStats = {
                    try {
                        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    Toast.makeText(context, "Hãy cho phép 'System Optimizer' truy cập", Toast.LENGTH_LONG).show()
                }
            )

            // Dynamic State-based UI
            Crossfade(targetState = uiState, label = "stateTransition") { state ->
                when (state) {
                    is UiState.Idle -> {
                        DashboardIdleView(
                            ramPercent = ramPercent,
                            ramText = ramText,
                            onScanClick = { viewModel.startScan() }
                        )
                    }
                    is UiState.Scanning -> {
                        ScanningView(
                            progressText = state.progressText,
                            progressVal = state.percentage
                        )
                    }
                    is UiState.ScanSuccess -> {
                        ScanSuccessView(
                            apps = state.apps,
                            totalCache = state.totalCacheSize,
                            totalRam = state.totalRamImpact,
                            isAccessibilityEnabled = isAccessibilityEnabled,
                            onAppSelectToggle = { viewModel.toggleAppSelection(it) },
                            onAppWhitelistToggle = { viewModel.toggleAppWhitelist(it) },
                            onQuickRamBoost = { viewModel.quickRamBoost() },
                            onDeepCleanCache = {
                                viewModel.startAutomatedDeepSweep(AutoCleanerService.ActionType.CLEAR_CACHE)
                            },
                            onHibernateApps = {
                                viewModel.startAutomatedDeepSweep(AutoCleanerService.ActionType.FORCE_STOP)
                            }
                        )
                    }
                    is UiState.Boosting -> {
                        BoostingView(statusText = state.currentAppName) {
                            viewModel.cancelSweep()
                        }
                    }
                    is UiState.BoostSuccess -> {
                        BoostSuccessView(
                            freedRam = state.freedRamMb,
                            freedCache = state.freedCacheMb,
                            onDone = { viewModel.resetToIdle() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionBanner(
    isAccessibilityEnabled: Boolean,
    isUsageStatsEnabled: Boolean,
    onRequestAccessibility: () -> Unit,
    onRequestUsageStats: () -> Unit
) {
    if (!isAccessibilityEnabled || !isUsageStatsEnabled) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Yêu cầu quyền hoạt động",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 15.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Để dọn dẹp bộ nhớ đệm tự động và ép ngủ đông ứng dụng triệt để, ứng dụng cần 2 quyền nâng cao dưới đây:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!isUsageStatsEnabled) {
                        Button(
                            onClick = onRequestUsageStats,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_grant_usage_stats")
                        ) {
                            Text("1. Thống kê sử dụng", fontSize = 11.sp, maxLines = 1)
                        }
                    }
                    if (!isAccessibilityEnabled) {
                        Button(
                            onClick = onRequestAccessibility,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_grant_accessibility")
                        ) {
                            Text("2. Trợ năng (Auto)", fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardIdleView(
    ramPercent: Float,
    ramText: String,
    onScanClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // High-tech Zero-Overhead Circular RAM indicator
        Box(
            modifier = Modifier.size(220.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                progress = { ramPercent },
                modifier = Modifier.fillMaxSize(),
                strokeWidth = 14.dp,
                color = if (ramPercent > 0.8f) Color(0xFFE57373) else Color(0xFF64B5F6),
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${(ramPercent * 100).toInt()}%",
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = if (ramPercent > 0.8f) Color(0xFFE57373) else Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "RAM ĐANG DÙNG",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Bộ nhớ trống: $ramText",
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(48.dp))
        Button(
            onClick = onScanClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("scan_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFFFB74D)
            ),
            shape = RoundedCornerShape(28.dp)
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(10.dp))
            Text("PHÂN TÍCH HỆ THỐNG", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun ScanningView(progressText: String, progressVal: Float) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(72.dp),
            strokeWidth = 6.dp,
            color = Color(0xFFFFB74D)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "ĐANG QUÉT THIẾT BỊ...",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = progressText,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))
        LinearProgressIndicator(
            progress = { progressVal },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape),
            color = Color(0xFFFFB74D),
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun ScanSuccessView(
    apps: List<AppInfo>,
    totalCache: Long,
    totalRam: Long,
    isAccessibilityEnabled: Boolean,
    onAppSelectToggle: (String) -> Unit,
    onAppWhitelistToggle: (String) -> Unit,
    onQuickRamBoost: () -> Unit,
    onDeepCleanCache: () -> Unit,
    onHibernateApps: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "KẾT QUẢ PHÂN TÍCH",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFFFFB74D),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Rác bộ đệm (Cache)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        Text(
                            text = formatBytes(totalCache),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Nền ngốn RAM",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "$totalRam MB",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Action Options
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Quick RAM Boost
            Button(
                onClick = onQuickRamBoost,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("btn_quick_boost"),
                shape = RoundedCornerShape(22.dp)
            ) {
                Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Tăng tốc RAM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // Deep Cache Clean (Accessibility)
            Button(
                onClick = onDeepCleanCache,
                enabled = isAccessibilityEnabled,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81C784)),
                modifier = Modifier
                    .weight(1.2f)
                    .height(44.dp)
                    .testTag("btn_deep_clean"),
                shape = RoundedCornerShape(22.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Xóa Cache Sâu", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }

            // Hibernate Apps (Force Stop Accessibility)
            Button(
                onClick = onHibernateApps,
                enabled = isAccessibilityEnabled,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64B5F6)),
                modifier = Modifier
                    .weight(1.2f)
                    .height(44.dp)
                    .testTag("btn_hibernate"),
                shape = RoundedCornerShape(22.dp)
            ) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Đóng băng", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }

        if (!isAccessibilityEnabled) {
            Text(
                text = "💡 Kích hoạt quyền Trợ năng (Auto) để mở khóa 'Xóa Cache Sâu' và 'Đóng băng'",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFFD54F),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "DANH SÁCH ỨNG DỤNG",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        // Lazy app list
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
        ) {
            items(apps) { app ->
                AppRowItem(
                    app = app,
                    onSelect = { onAppSelectToggle(app.packageName) },
                    onWhitelistToggle = { onAppWhitelistToggle(app.packageName) }
                )
            }
        }
    }
}

@Composable
fun AppRowItem(
    app: AppInfo,
    onSelect: () -> Unit,
    onWhitelistToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(enabled = !app.isWhitelisted) { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (app.isWhitelisted) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            }
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox for selection
            Checkbox(
                checked = app.isSelected && !app.isWhitelisted,
                onCheckedChange = { onSelect() },
                enabled = !app.isWhitelisted,
                modifier = Modifier.testTag("checkbox_${app.packageName}")
            )

            // High performance initials-based app icon (prevents OutOfMemory issues)
            AppInitialsIcon(name = app.appName)

            Spacer(modifier = Modifier.width(12.dp))

            // Text section
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = app.appName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (app.isWhitelisted) Color.White.copy(alpha = 0.5f) else Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Cache: ${formatBytes(app.cacheSize)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RAM: ~${app.ramImpactMb}MB",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }

            // Whitelist Toggle button
            IconButton(
                onClick = onWhitelistToggle,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("whitelist_btn_${app.packageName}")
            ) {
                Icon(
                    imageVector = if (app.isWhitelisted) Icons.Default.VerifiedUser else Icons.Outlined.Security,
                    contentDescription = "whitelist",
                    tint = if (app.isWhitelisted) Color(0xFF81C784) else Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AppInitialsIcon(name: String, modifier: Modifier = Modifier) {
    val initials = name.trim().take(1).uppercase()
    val colorIndex = name.hashCode().absoluteValue % 6
    val bgColors = listOf(
        Color(0xFFE57373), Color(0xFF81C784), Color(0xFF64B5F6),
        Color(0xFFFFD54F), Color(0xFFBA68C8), Color(0xFF4DB6AC)
    )
    val color = bgColors[colorIndex]
    Box(
        modifier = modifier
            .size(40.dp)
            .background(color.copy(alpha = 0.8f), shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            fontSize = 16.sp
        )
    }
}

@Composable
fun BoostingView(statusText: String, onCancel: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(72.dp),
            strokeWidth = 6.dp,
            color = Color(0xFFFFB74D)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "HỆ THỐNG ĐANG TỰ ĐỘNG TỐI ƯU HÓA...",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFFFB74D),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                textAlign = TextAlign.Center
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Vui lòng giữ nguyên màn hình để Trợ lý tự động click và dọn dẹp.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedButton(
            onClick = onCancel,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) {
            Text("Hủy bỏ tự động hóa")
        }
    }
}

@Composable
fun BoostSuccessView(
    freedRam: Long,
    freedCache: Long,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF81C784),
            modifier = Modifier.size(96.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "TỐI ƯU HOÀN TẤT!",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (freedRam > 0) {
                    Text(
                        text = "Giải phóng RAM: ~$freedRam MB",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64B5F6),
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                if (freedCache > 0) {
                    Text(
                        text = "Dọn sạch bộ đệm: $freedCache MB",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF81C784),
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = "Thiết bị của bạn giờ đã nhẹ, mát và FPS ổn định hơn!",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
        Button(
            onClick = onDone,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("done_button"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB74D))
        ) {
            Text("QUAY LẠI TRANG CHỦ", fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 Bytes"
    val k = 1024L
    val sizes = arrayOf("Bytes", "KB", "MB", "GB")
    val i = (Math.log(bytes.toDouble()) / Math.log(k.toDouble())).toInt().coerceIn(0, 3)
    return String.format("%.2f %s", bytes.toDouble() / Math.pow(k.toDouble(), i.toDouble()), sizes[i])
}
