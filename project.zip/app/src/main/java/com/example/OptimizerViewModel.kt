package com.example

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class UiState {
    object Idle : UiState()
    data class Scanning(val progressText: String, val percentage: Float) : UiState()
    data class ScanSuccess(val apps: List<AppInfo>, val totalCacheSize: Long, val totalRamImpact: Long) : UiState()
    data class Boosting(val currentAppName: String) : UiState()
    data class BoostSuccess(val freedRamMb: Long, val freedCacheMb: Long) : UiState()
}

class OptimizerViewModel(private val context: Context) : ViewModel() {

    private val scanner = AppScanner(context)
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled: StateFlow<Boolean> = _isAccessibilityEnabled.asStateFlow()

    private val _isUsageStatsEnabled = MutableStateFlow(false)
    val isUsageStatsEnabled: StateFlow<Boolean> = _isUsageStatsEnabled.asStateFlow()

    // RAM stats
    private val _ramUsagePercent = MutableStateFlow(0f)
    val ramUsagePercent: StateFlow<Float> = _ramUsagePercent.asStateFlow()

    private val _ramAvailableText = MutableStateFlow("")
    val ramAvailableText: StateFlow<String> = _ramAvailableText.asStateFlow()

    private var currentScanApps = listOf<AppInfo>()
    private var sweepJob: Job? = null

    init {
        checkPermissions()
        updateRamStats()
        
        // Listen to accessibility service connection status
        viewModelScope.launch {
            AutoCleanerService.isServiceRunning.collectLatest { running ->
                _isAccessibilityEnabled.value = running
            }
        }
    }

    fun checkPermissions() {
        _isAccessibilityEnabled.value = AutoCleanerService.isServiceRunning.value
        _isUsageStatsEnabled.value = isUsageStatsPermissionGranted()
    }

    private fun isUsageStatsPermissionGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun updateRamStats() {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        
        val total = memInfo.totalMem.toFloat()
        val avail = memInfo.availMem.toFloat()
        val used = total - avail
        
        _ramUsagePercent.value = used / total
        _ramAvailableText.value = String.format("%.2f GB / %.2f GB", avail / (1024 * 1024 * 1024), total / (1024 * 1024 * 1024))
    }

    fun toggleAppSelection(packageName: String) {
        val currentState = _uiState.value
        if (currentState is UiState.ScanSuccess) {
            val updatedList = currentState.apps.map { app ->
                if (app.packageName == packageName) {
                    app.copy(isSelected = !app.isSelected)
                } else app
            }
            currentScanApps = updatedList
            val totalCache = updatedList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.cacheSize }
            val totalRam = updatedList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.ramImpactMb }
            _uiState.value = UiState.ScanSuccess(updatedList, totalCache, totalRam)
        }
    }

    fun toggleAppWhitelist(packageName: String) {
        val currentState = _uiState.value
        if (currentState is UiState.ScanSuccess) {
            val isCurrentlyWhitelisted = scanner.isAppWhitelisted(packageName)
            scanner.toggleWhitelist(packageName, !isCurrentlyWhitelisted)
            
            // Re-run scan state refresh
            val updatedList = currentState.apps.map { app ->
                if (app.packageName == packageName) {
                    app.copy(isWhitelisted = !isCurrentlyWhitelisted, isSelected = isCurrentlyWhitelisted)
                } else app
            }
            currentScanApps = updatedList
            val totalCache = updatedList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.cacheSize }
            val totalRam = updatedList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.ramImpactMb }
            _uiState.value = UiState.ScanSuccess(updatedList, totalCache, totalRam)
        }
    }

    fun startScan() {
        viewModelScope.launch {
            _uiState.value = UiState.Scanning("Bắt đầu quét...", 0f)
            delay(400) // Beautiful smooth transition delay
            
            val appsList = scanner.scanInstalledApps { current, total ->
                val progress = current.toFloat() / total
                _uiState.value = UiState.Scanning(
                    progressText = "Đang quét ứng dụng ($current / $total)...",
                    percentage = progress
                )
            }
            
            currentScanApps = appsList
            val totalCache = appsList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.cacheSize }
            val totalRam = appsList.filter { it.isSelected && !it.isWhitelisted }.sumOf { it.ramImpactMb }
            _uiState.value = UiState.ScanSuccess(appsList, totalCache, totalRam)
            updateRamStats()
        }
    }

    /**
     * Boosts RAM instantly using killBackgroundProcesses
     */
    fun quickRamBoost() {
        val currentState = _uiState.value
        if (currentState is UiState.ScanSuccess) {
            viewModelScope.launch {
                _uiState.value = UiState.Boosting("Đang giải phóng bộ nhớ RAM...")
                
                val selectedApps = currentState.apps.filter { it.isSelected && !it.isWhitelisted }
                val freedBytes = scanner.killBackgroundProcesses(selectedApps)
                val freedMb = freedBytes / (1024 * 1024)

                delay(1200) // Let user see the gorgeous progress
                _uiState.value = UiState.BoostSuccess(freedRamMb = freedMb, freedCacheMb = 0L)
                updateRamStats()
            }
        }
    }

    /**
     * Automated Deep Sweep for Cache Cleaning or Force Stop (Hibernation)
     */
    fun startAutomatedDeepSweep(action: AutoCleanerService.ActionType) {
        val currentState = _uiState.value
        if (currentState !is UiState.ScanSuccess) return
        if (!AutoCleanerService.isServiceRunning.value) {
            Log.e("ViewModel", "Accessibility service is not active!")
            return
        }

        sweepJob = viewModelScope.launch {
            val targetApps = currentState.apps.filter { it.isSelected && !it.isWhitelisted }
            if (targetApps.isEmpty()) {
                _uiState.value = UiState.BoostSuccess(freedRamMb = 0, freedCacheMb = 0)
                return@launch
            }

            _uiState.value = UiState.Boosting("Đang tối ưu hóa sâu các ứng dụng...")
            AutoCleanerService.isSweepingActive.value = true
            AutoCleanerService.currentAction.value = action

            var totalFreedCache: Long = 0
            var totalFreedRam: Long = 0

            for (app in targetApps) {
                _uiState.value = UiState.Boosting(
                    "Đang xử lý: ${app.appName}\n" +
                    (if (action == AutoCleanerService.ActionType.CLEAR_CACHE) "Xóa cache" else "Ép đóng băng")
                )

                AutoCleanerService.currentSweepingPackage.value = app.packageName
                
                // Navigate user to details settings page
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${app.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)

                // Wait for the Accessibility service to complete or timeout
                var waitTime = 0
                val timeoutLimit = 2200 // Max 2.2 seconds per app to ensure speed
                while (waitTime < timeoutLimit) {
                    delay(150)
                    waitTime += 150
                    if (AutoCleanerService.lastCompletedPackage.value == app.packageName) {
                        Log.d("ViewModel", "Completed app ${app.packageName}")
                        break
                    }
                }

                if (action == AutoCleanerService.ActionType.CLEAR_CACHE) {
                    totalFreedCache += app.cacheSize
                } else {
                    totalFreedRam += app.ramImpactMb
                }
            }

            // Clean up and back to main application
            AutoCleanerService.isSweepingActive.value = false
            AutoCleanerService.currentAction.value = AutoCleanerService.ActionType.NONE
            AutoCleanerService.currentSweepingPackage.value = null
            
            // Bring main app back to foreground
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(launchIntent)

            delay(800)
            _uiState.value = UiState.BoostSuccess(
                freedRamMb = totalFreedRam,
                freedCacheMb = totalFreedCache / (1024 * 1024)
            )
            updateRamStats()
        }
    }

    fun cancelSweep() {
        sweepJob?.cancel()
        AutoCleanerService.isSweepingActive.value = false
        AutoCleanerService.currentAction.value = AutoCleanerService.ActionType.NONE
        AutoCleanerService.currentSweepingPackage.value = null
        _uiState.value = UiState.Idle
        updateRamStats()
    }

    fun resetToIdle() {
        _uiState.value = UiState.Idle
        updateRamStats()
    }
}

class ViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(OptimizerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return OptimizerViewModel(context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
